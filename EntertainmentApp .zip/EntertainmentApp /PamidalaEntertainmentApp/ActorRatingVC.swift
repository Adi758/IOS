//
//  ActorRatingVC.swift
//  PamidalaEntertainmentApp
//
//  Created by Pamidala,Chandra Adithya on 4/18/23.
//

import UIKit

class ActorRatingVC: UIViewController {

    @IBOutlet var actorIMG: UIImageView!
    
    @IBOutlet var danceTF: UITextField!
    
    @IBOutlet var actingTF: UITextField!
    
    @IBOutlet var actionEpisodesTF: UITextField!
    
    @IBOutlet var overallPerformanceSlider: UISlider!
    
    
    @IBOutlet var emojisPV: UIPickerView!
    let reactions = ["💩", "😍", "💀", "🔥", "👌"]
    
    var actorIndex = -1
    var actor: Actor? = nil
    
    var textFieldTag = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.actorIMG.layer.cornerRadius = 20.0
        
        
        self.actorIMG.clipsToBounds = true
        
        self.actorIMG.layer.borderColor = UIColor.black.cgColor
        self.actorIMG.layer.borderWidth = 2.0
        
        self.actingTF.placeholder = "Acting"
        self.danceTF.placeholder = "Dance"
        self.actionEpisodesTF.placeholder = "Fights"
        // Do any additional setup after loading the view.
        
        self.overallPerformanceSlider.minimumValue = 0
        self.overallPerformanceSlider.maximumValue = 10
        
        self.setData()
        
        self.actingTF.tag = 1
        self.actingTF.addTarget(self, action: #selector(beginEditing(sender: )), for: .editingDidBegin)

        self.danceTF.tag = 2
        self.danceTF.addTarget(self, action: #selector(beginEditing(sender: )), for: .editingDidBegin)
        
        self.actionEpisodesTF.tag = 3
        self.actionEpisodesTF.addTarget(self, action: #selector(beginEditing(sender: )), for: .editingDidBegin)
    }
    
    
    @objc func beginEditing(sender: UITextField) {
        
        sender.resignFirstResponder()
        self.textFieldTag = sender.tag
        self.emojisPV.isHidden = false
    }
    
    func setData() {
    
        self.actor = actors[actorIndex]
        
        self.actorIMG.image = UIImage(named: actor!.actorImageName)
        
        self.danceTF.text = actor!.dancingSkills
        self.actingTF.text = actor!.performingSkills
        self.actionEpisodesTF.text = actor!.actionEpisodes
        self.overallPerformanceSlider.value = actor!.overallRating
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func save(_ sender: Any) {
        
        
        let alert = UIAlertController(title: "Success", message: "Rating are saved", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Done", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
        
        self.saveRating()
        self.emojisPV.isHidden = true
        
    }
    
    
    @IBAction func clearRatings(_ sender: Any) {
        
        self.actingTF.text = ""
        self.danceTF.text = ""
        self.actionEpisodesTF.text = ""
        self.overallPerformanceSlider.value = 0
        
        self.saveRating()
    }
    
    
    func saveRating() {
        
        var actor = actors[actorIndex]
        
        actor.dancingSkills = self.danceTF.text ?? ""
        actor.overallRating = self.overallPerformanceSlider.value
        actor.performingSkills = self.actingTF.text ?? ""
        actor.actionEpisodes = self.actionEpisodesTF.text ?? ""
        
        actors[actorIndex] = actor
        
    }
}


extension ActorRatingVC: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
    }
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        let reaction = reactions[row]
        return reaction
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        self.emojisPV.isHidden = true
        
        let reaction = reactions[row]
        if textFieldTag == 1 {
            
            self.actingTF.text = reaction
        }else if textFieldTag == 2 {
            
            self.danceTF.text = reaction
        }else {
            
            self.actionEpisodesTF.text = reaction
        }
        
        
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        return reactions.count
    }
    
}
