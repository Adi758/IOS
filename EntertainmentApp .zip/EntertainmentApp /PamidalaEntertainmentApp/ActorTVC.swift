//
//  ActorTVC.swift
//  PamidalaEntertainmentApp
//
//  Created by Pamidala,Chandra Adithya on 4/18/23.
//

import UIKit

class ActorTVC: UITableViewCell {

    @IBOutlet var imgView: UIImageView!
    
    
    @IBOutlet var nameLbl: UILabel!
    
    @IBOutlet var activeLbl: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
