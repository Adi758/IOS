//
//  MusicVC.swift
//  PamidalaEntertainmentApp
//
//  Created by Pamidala,Chandra Adithya on 4/18/23.
//

import UIKit
import ViewAnimator


class MusicVC: UIViewController {

    
    @IBOutlet var musicTV: UITableView!
    
    var musics: [Music] = []
    var favourites: [Music] = []
    
    var section = -1
    var row = -1
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.getMusicList()
        // Do any additional setup after loading the view.
    }
    
    
    func getMusicList() {
        
        let music1 = Music(title: "Jai Lava Kusa Video Songs",
                           composer: "RAAVANA Full Video Song | Jr NTR, Nivetha Thomas | Devi Sri Prasad",
                           videoId: "LQeE4hFIQqE")
        self.musics.append(music1)
        
        
        
        let music2 = Music(title: "Master - Master Coming Video (Telugu)",
                           composer: "Thalapathy Vijay | Anirudh Ravichander | Lokesh Kanagaraj",
                           videoId: "qItykoFeqNE")
        self.musics.append(music2)
        
        
        
        let music3 = Music(title: "Ma Ma Mahesha - Video Song ",
                           composer: "Sarkaru Vaari Paata | Mahesh Babu | Keerthy Suresh | Thaman S",
                           videoId: "3kcadMVFolY")
        self.musics.append(music3)
        
        
        
        let music4 = Music(title: "Akhanda Title Song [4K]",
                           composer: "Nandamuri Balakrishna | Boyapati Sreenu |Thaman S |Telugu Hits",
                           videoId: "SPinDXYJ9CA")
        self.musics.append(music4)
        
        
        
        let music5 = Music(title: "Chirutha Video Songs",
                           composer: "Chamka Chamka Video Song | Ramcharan, Neha Sharma | Sri Balaji Video",
                           videoId: "RuDQUYwVjCo")
        self.musics.append(music5)
        
        
        
        let music6 = Music(title: "SARRAINODU Full Video Song",
                           composer: "Sarrainodu || Allu Arjun, Rakul Preet",
                           videoId: "MkaUB7iQaQ8")
        self.musics.append(music6)
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let animations = AnimationType.from(direction: .top, offset: 70.0)
        UIView.animate(views: musicTV.visibleCells,
                       animations: [animations])
    }
    
    // MARK: - Navigatio
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "track" {
            
            let vc = segue.destination as! PlayMusicVC
            
            var selected: Music? = nil
            if self.section == 0 {
                
                selected = self.musics[row]
            }else {
                
                selected = self.favourites[row]
            }
            
            vc.videoID = selected?.videoId ?? ""
            vc.titleStr = selected?.title ?? ""
        }
    }
    

}

extension MusicVC: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section == 0 {
            
            return self.musics.count
        }else if section == 1 {
            
            return self.favourites.count
        }
        
        return 0
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "Cell")
        
        var music: Music? = nil
        
        if indexPath.section == 0 {
            
            music = musics[indexPath.row]
            
        }else if indexPath.section == 1 {
            
            music = favourites[indexPath.row]
            
        }
        
        cell.accessoryType = .disclosureIndicator
        cell.textLabel?.text = music?.title
        cell.detailTextLabel?.text = music?.composer
        cell.imageView?.image = UIImage(systemName: "music.note.list")
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.section = indexPath.section
        self.row = indexPath.row
        
        self.performSegue(withIdentifier: "track", sender: self)
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        if section == 0 {
            
            return "Songs"
        }else if section == 1 {
            
            return "Favorites"
        }
        
        return ""
    }
    

    
    func tableView(_ tableView: UITableView,
                   leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?{
        
        if indexPath.section == 0 {
            
            let closeAction = UIContextualAction(style: .normal, title:  "", handler: { (ac:UIContextualAction, view:UIView, success:(Bool) -> Void) in
                
                success(true)
                
                let selected = self.musics[indexPath.row]
                var isFound = false
                
                for fav in self.favourites {
                    
                    if fav.videoId == selected.videoId {
                        
                        isFound = true
                    }
                }
                
                if !isFound {
                    
                    self.favourites.append(selected)
                }
                 
                self.musicTV.reloadData()
                
            })
            closeAction.image = UIImage.init(systemName: "heart")
            closeAction.backgroundColor = .purple
            
            
            return UISwipeActionsConfiguration(actions: [closeAction])
        }
        
        return nil
    }
    
}
