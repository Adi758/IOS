//
//  PlayMusicVC.swift
//  PamidalaEntertainmentApp
//
//  Created by Pamidala,Chandra Adithya on 4/18/23.
//

import UIKit
import YouTubeiOSPlayerHelper

class PlayMusicVC: UIViewController {

    @IBOutlet var videoPlayerView: YTPlayerView!
    
    var titleStr = ""
    var videoID = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = self.titleStr
        
        self.videoPlayerView.load(withVideoId: self.videoID)
        self.videoPlayerView.playVideo()
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        
        self.videoPlayerView.stopVideo()
    }
}
