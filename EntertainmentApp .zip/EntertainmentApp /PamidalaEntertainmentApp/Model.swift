//
//  Model.swift
//  PamidalaEntertainmentApp
//
//  Created by Pamidala,Chandra Adithya on 4/18/23.
//

import Foundation

var actors: [Actor] = []


struct Music{
    
    
    var title: String
    var composer: String
    var videoId: String
    
}



struct Actor{
    
    
    var fullName: String
    var yearsActive: String
    var movies: [String]
    var actorImageName: String
    var actionEpisodes: String
    var dancingSkills: String
    var performingSkills: String
    var overallRating: Float
    
    
}

