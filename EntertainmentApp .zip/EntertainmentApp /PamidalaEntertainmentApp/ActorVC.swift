//
//  ActorVC.swift
//  PamidalaEntertainmentApp
//
//  Created by Pamidala,Chandra Adithya on 4/18/23.
//

import UIKit
import SDWebImage
import ViewAnimator

class ActorVC: UIViewController {

    
    @IBOutlet var actorsTableView: UITableView!
    
   // var actors: [Actor] = []
    var actorMovies: [String] = []
    var actorIndex = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.getActorsList()
        
    }
    

    override func viewDidAppear(_ animated: Bool) {
        
        let animations = AnimationType.from(direction: .top, offset: 70.0)
        UIView.animate(views: actorsTableView.visibleCells,
                       animations: [animations])
        
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    func getActorsList() {
        
        var moviesList = [
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRPhHAKNEh-ZKjII2Gtr2MYk8rnKafGBoiwBA&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS8SFjdmnUYWkzSzxJyUPkDQcIh9_lJzU048w&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQu_MbjAtcdudG-Npbo3dOylWW8UMb7GBlcGg&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRUMocd25kNhFqmGIbiglpEwsBspKlXIkUhwQ&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDToj4CcCoGeDKcBsKZp52fj_j_wdowqnfbA&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSefoy4DVyr_3ugugzhYLk0d1edbIqSA0dGMg&usqp=CAU"]
        
        
        
        let actor1 = Actor(fullName: "Jr NTR", yearsActive: "1991 to present", movies: moviesList, actorImageName: "ntr", actionEpisodes: "", dancingSkills: "", performingSkills: "", overallRating: 0.0)
        
        actors.append(actor1)
        
        
        moviesList = [
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUEPk5Zb51GEutaCBGDeGwO0oyATwKyN0Afw&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3zTMpxyjmw229CzeQX4cUECcG6wP_Ocu59w&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQc_MM64oJcpo4pA1b9cy-daxwi3ef2lpCo9A&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNFGObhB3jwVs9b6NeSzMPjHPCkHu-npJ2ig&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQwAvFhFK2dQc0nmWq3PNjUR3F6scgCraNeRw&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQ3vJEa_1iNNl_MhrtybSAJpBhm5gTxxw6JbXK_2nZ5Z-Dc-OAs5Nw-QOScbwdgSeEWg0&usqp=CAU"]
        
        let actor2 = Actor(fullName: "Mahesh Babu", yearsActive: "1979 to present", movies: moviesList, actorImageName: "MaheshBabu", actionEpisodes: "", dancingSkills: "", performingSkills: "", overallRating: 0.0)
        
        actors.append(actor2)
        
        moviesList = [
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7k6OQML0yyI6lhO0ieA48aInPhVDxGZAibA&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcScPvS9EVdpUOE1QgQ1PqByIpR8-qGNV55DHQ&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmle9GH3Ll3Ci_B1ehMpOUURWFSzsPxbwes6BTC7rtFghqx6HoivWqXXYCHNQfw13JKZg&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSZDNiWlK_co1-65cCAkQ84FTOqK-DhlQLmQg&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTP8XndrHJNFZkY2SySTRy1mBzaH-yj6jYTvA&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQSXfdVHAc3yfVPRRofeVjvG6fKA5YLd17zA&usqp=CAU"]
        
        let actor3 = Actor(fullName: "Nandamuri Bala Krishna", yearsActive: "1974 to present", movies: moviesList, actorImageName: "Nandamuri", actionEpisodes: "", dancingSkills: "", performingSkills: "", overallRating: 0.0)
        
        actors.append(actor3)
        
        
        moviesList = [
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSM8OQzt2Ozyo2-9wdV4CqZtrtSdxuSqWm_Q&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8RN4uMsO59sH6Iovyafo1Xwa_E1SqE1JTSQ&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_yE6iJurNpCv1nXtZR1AaCS32KCyArW3avA&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBazalPKpul-BfvE6w_4fnyxOk4fvNl2ySDBLZbL42aII7aWoBsgJc0DOBK_z663TUsag&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQybOm0FhOlx4H6OxoO2HtNWtYtDfz0gqvefg&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjtgB5hxIxXYfFB8SICDEYOZxnvpsoB9ntXw&usqp=CAU"]
        
        let actor4 = Actor(fullName: "Vijay Thalapathy", yearsActive: "1984 to present", movies: moviesList, actorImageName: "Vijay", actionEpisodes: "", dancingSkills: "", performingSkills: "", overallRating: 0.0)
        
        actors.append(actor4)
        
        moviesList = [
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxxYKkYtUyM_QoGuHZZyxojAujdI8aTqi2wA&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1V1u-obaUMwwUwkSA0qsPmiHhv4b5v-mypA&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTRLselVfRZ7Pbm_NUQ4I7vr1d00TCSA8AAOQ&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ3JknS3BycAIblJUlvI433yXcZ_qrTOX8evFb7yPhsIw72G2O9TXurWfaDIFy8z7NWtus&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT-5Z2ErJyAqhN3zZ3AgcbZHKc6kGe5fYbvtQ&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTYOhogo_eXGtu7zd2n1TL1PF_mQtEVY7XQHw&usqp=CAU"]
        
        let actor5 = Actor(fullName: "Ram Charan", yearsActive: "2002 to present", movies: moviesList, actorImageName: "RamCharan", actionEpisodes: "", dancingSkills: "", performingSkills: "", overallRating: 0.0)
        
        actors.append(actor5)
        
        moviesList = [
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAWpNHp_hQsuJPWxoOxFUXgTQX3OTRlnpexQ&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWrue0iUkNdrTH5fXEIBY2RYIBNDmafKXPSA&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1317jvHuAWPZmazgBJzjBk_2Ogl5-B-OjZg&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRRwVTlYPF0fG0V05QGzTKSPikicGg2mlAdm5bBmzehHWenvEKpAMtFASaBI4AZ1Cl0rzg&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRAi_NQk-G9d3dZxWfeAynkyMBDqVzee8EgFg&usqp=CAU",
            "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTBikBpCDcNUfVK6ZFSny5t9ryF6wlNeX6wIQ&usqp=CAU"]
        
        let actor6 = Actor(fullName: "Allu Arjun", yearsActive: "2001 to present", movies: moviesList, actorImageName: "AlluArjun", actionEpisodes: "", dancingSkills: "", performingSkills: "", overallRating: 0.0)
        
        actors.append(actor6)
    }
    
    
    // MARK: - Navigation
    
    
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         
         if segue.identifier == "filmography" {
             
             let vc = segue.destination as! FilmographyVC
             vc.actorMovies = actorMovies
             
             
         }else if segue.identifier == "rating" {
             
             
             let vc = segue.destination as! ActorRatingVC
             vc.actorIndex = self.actorIndex
         }
     }
    
}


extension ActorVC: UITableViewDataSource, UITableViewDelegate {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return "List of actors"
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return actors.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = Bundle.main.loadNibNamed("ActorTVC", owner: self, options: nil)?.first as! ActorTVC
        
        let actor = actors[indexPath.row]
        
        
        cell.nameLbl.text = actor.fullName
        
        
        cell.activeLbl.text = actor.yearsActive
        
        cell.imgView.image = UIImage(named: actor.actorImageName)
       
        cell.imgView.contentMode = .scaleToFill
        
        
        cell.imgView.layer.cornerRadius = 5.0
        cell.imgView.layer.borderColor = UIColor.black.cgColor
        cell.imgView.layer.borderWidth = 1.0
        cell.imgView.clipsToBounds = true
        
        
        cell.accessoryType = .detailButton
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.actorMovies = actors[indexPath.item].movies
        
        self.performSegue(withIdentifier: "filmography", sender: self)
    }

    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 100
    }
    

    
    
    
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        
        self.actorIndex = indexPath.row
        self.performSegue(withIdentifier: "rating", sender: self)
    }
    
    
    
}
