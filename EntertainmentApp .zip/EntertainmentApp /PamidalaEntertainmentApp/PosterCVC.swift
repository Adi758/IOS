//
//  PosterCVCCollectionViewCell.swift
//  PamidalaEntertainmentApp
//
//  Created by Pamidala,Chandra Adithya on 4/18/23.
//

import UIKit

class PosterCVC: UICollectionViewCell {
    
    @IBOutlet var moviePosterIV: UIImageView!
}
