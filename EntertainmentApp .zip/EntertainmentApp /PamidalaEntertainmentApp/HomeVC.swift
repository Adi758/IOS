//
//  HomeVC.swift
//  PamidalaEntertainmentApp
//
//  Created by Pamidala,Chandra Adithya on 4/18/23.
//

import UIKit

class HomeVC: UIViewController {

    @IBOutlet var profileIV: UIImageView!
    
    @IBOutlet var phoneLbl: UILabel!
    
    @IBOutlet var emailLbl: UILabel!
    
    @IBOutlet var bioTextView: UITextView!
    
    @IBOutlet var nameLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.setData()
    }
    
    
    func setData() {
        
        self.profileIV.image = UIImage(named: "profileImg")
        self.profileIV.layer.cornerRadius = 20.0
        
        
        self.profileIV.layer.masksToBounds = true
        
        self.profileIV.layer.borderColor = UIColor(red: 0.0, green: 103.0, blue: 71.0, alpha: 1.0).cgColor
        self.profileIV.layer.borderWidth = 2.0
        
        self.nameLbl.text = "Chandra Adithya Pamidala"

        self.emailLbl.text = "adithya@gmail.com"
        
        self.phoneLbl.text = "+1 (848)234-8997"
        
        self.bioTextView.text = "I am graduate student pursing my masters at the Northwest Missouri State University, MO. My major is Applied Computer Science. I will be graduated in May 2023"
        
        bioTextView.isSelectable = false
        bioTextView.isEditable = false
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
