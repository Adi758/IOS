//
//  ViewController.swift
//  PamidalaEntertainmentApp
//
//  Created by Pamidala,Chandra Adithya on 4/18/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

