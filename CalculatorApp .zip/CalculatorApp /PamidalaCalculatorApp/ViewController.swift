//
//  ViewController.swift
//  PamidalaCalculatorApp
//
//  Created by Pamidala,Chandra Adithya on 2/13/23.
//

import UIKit

class CalculatorVC: UIViewController {

    @IBOutlet weak var mathExpressionLBL: UILabel!
    
    
    @IBAction func clearExpression(_ sender: Any) {
    }
    
    @IBAction func flipSign(_ sender: Any) {
    }
    
    @IBAction func percent(_ sender: Any) {
    }
    
    @IBAction func naturalLog(_ sender: Any) {
    }
    
    
    @IBAction func factorial(_ sender: Any) {
    }
    
    
    @IBAction func tenPow(_ sender: Any) {
    }
    
    @IBAction func calcSin(_ sender: Any) {
    }
    
    @IBAction func calcCos(_ sender: Any) {
    }
    
    @IBAction func calcTan(_ sender: Any) {
    }
    
    
    @IBAction func inverse(_ sender: Any) {
    }
    
    
    @IBAction func tappedChar(_ sender: Any) {
    }
    
 
    @IBAction func result(_ sender: Any) {
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

